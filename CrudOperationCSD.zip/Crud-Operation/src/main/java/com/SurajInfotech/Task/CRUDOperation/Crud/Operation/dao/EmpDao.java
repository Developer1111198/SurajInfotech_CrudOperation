package com.SurajInfotech.Task.CRUDOperation.Crud.Operation.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.criteria.HibernateCriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.SurajInfotech.Task.CRUDOperation.Crud.Operation.entity.EmployeeInformation;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;

@Repository
public class EmpDao {

	@Autowired
	private SessionFactory sf;
	
	public List<EmployeeInformation> getAllInformation() {
		Session session = sf.openSession();
		CriteriaQuery<EmployeeInformation> criteria= session.getCriteriaBuilder().createQuery(EmployeeInformation.class);
		criteria.from(EmployeeInformation.class);
		List<EmployeeInformation> list = session.createQuery(criteria).getResultList();
		return list;
	}

	public EmployeeInformation getSingleInformation(int id) {
		Session session = sf.openSession();
		CriteriaQuery<EmployeeInformation> criteria= session.getCriteriaBuilder().createQuery(EmployeeInformation.class);
		criteria.from(EmployeeInformation.class);
		EmployeeInformation emp = session.get(EmployeeInformation.class, id);
		return emp;
	}

	public EmployeeInformation insertInformation(EmployeeInformation emp) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(emp);
		tr.commit();
		return emp;		
	}

	public EmployeeInformation updateInformation(EmployeeInformation emp) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.update(emp);
		tr.commit();
		return emp;
	}

	public EmployeeInformation deleteInformation(int id) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		EmployeeInformation employee = session.get(EmployeeInformation.class, id);
		session.delete(employee);
		tr.commit();
		return employee;
	}
	
	
}
