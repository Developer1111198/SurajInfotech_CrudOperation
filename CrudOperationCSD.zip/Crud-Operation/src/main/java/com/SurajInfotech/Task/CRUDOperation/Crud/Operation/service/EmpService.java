package com.SurajInfotech.Task.CRUDOperation.Crud.Operation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SurajInfotech.Task.CRUDOperation.Crud.Operation.dao.EmpDao;
import com.SurajInfotech.Task.CRUDOperation.Crud.Operation.entity.EmployeeInformation;

@Service
public class EmpService {

	@Autowired
	EmpDao dao;
	
	public List<EmployeeInformation> getAllInformation() {
		List<EmployeeInformation> list = dao.getAllInformation();
		return list;
	}

	public EmployeeInformation getSingleInformation(int id) {
		EmployeeInformation emp = dao.getSingleInformation(id);
		return emp;
	}

	public EmployeeInformation insertInformation(EmployeeInformation emp) {
		EmployeeInformation employee = dao.insertInformation(emp);
		return employee;
	}

	public EmployeeInformation updateInformation(EmployeeInformation emp) {
		EmployeeInformation employee = dao.updateInformation(emp);
		return employee;
	}

	public EmployeeInformation deleteInformation(int id) {
		EmployeeInformation employee = dao.deleteInformation(id);
		return employee;
	}
	

}
