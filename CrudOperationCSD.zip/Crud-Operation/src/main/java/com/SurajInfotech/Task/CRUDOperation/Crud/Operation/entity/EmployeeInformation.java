package com.SurajInfotech.Task.CRUDOperation.Crud.Operation.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class EmployeeInformation {
	@Id
	private int id;
	private String fName;
	private String lName;
	private String dept;
	private String workLoc;
	private long mobNo;
	private String emailId;
	
	public void setId(int id) {
		this.id=id;
	}
	public int getId() {
		return id;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getWorkLoc() {
		return workLoc;
	}
	public void setWorkLoc(String workLoc) {
		this.workLoc = workLoc;
	}
	public long getMobNo() {
		return mobNo;
	}
	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public EmployeeInformation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeeInformation(int id, String fName, String lName, String dept, String workLoc, long mobNo,
			String emailId) {
		super();
		this.id = id;
		this.fName = fName;
		this.lName = lName;
		this.dept = dept;
		this.workLoc = workLoc;
		this.mobNo = mobNo;
		this.emailId = emailId;
	}
	
	
}
