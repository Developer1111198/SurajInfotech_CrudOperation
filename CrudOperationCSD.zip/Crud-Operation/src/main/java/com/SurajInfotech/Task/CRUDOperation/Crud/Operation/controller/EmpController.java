package com.SurajInfotech.Task.CRUDOperation.Crud.Operation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.SurajInfotech.Task.CRUDOperation.Crud.Operation.entity.EmployeeInformation;
import com.SurajInfotech.Task.CRUDOperation.Crud.Operation.service.EmpService;

@RestController
public class EmpController {
	
	@Autowired
	EmpService es;
	
	@GetMapping("allempinformation")
	public List<EmployeeInformation> getAllInformation() {
		List<EmployeeInformation> list = es.getAllInformation();
		return list;
	}
	
	@GetMapping("getsingleempinformation/{id}")
	public EmployeeInformation getSingleInformation(@PathVariable int id) {
		EmployeeInformation emp = es.getSingleInformation(id);
		return emp;
	}
	
	@PostMapping("insertempinformation")
	public EmployeeInformation insertInformation(@RequestBody EmployeeInformation emp) {
		EmployeeInformation employee = es.insertInformation(emp);
		return employee;
	}
	
	@PutMapping("updateempinformation")
	public EmployeeInformation updateInformation(@RequestBody EmployeeInformation emp) {
		EmployeeInformation employee = es.updateInformation(emp);
		return employee;
	}
	
	@DeleteMapping("deleteempinformation/{id}")
	public EmployeeInformation deleteInformation(@PathVariable int id) {
		EmployeeInformation employee = es.deleteInformation(id);
		return employee;
	}
	
}